"""
TMA Reduction Layout Benchmark for H100 (SM90).

Study Case:
  shape = [1, 32, 128]
  input dtype = bf16
  acc / conversion = fp32
  reduce op = max
  reduce axis = 1
  num_warps = 4
  GPU = strict H100 (SM90)

Candidates:
  default, 8, 4, 2, 1

Audited Evidence Architecture:
  RAW: Raw samples, IR hashes, cubin dumps
  OBSERVED: TTGIR layout attributes, PTX whole-kernel op counts, LocalLoad lowering, physical resources
  DERIVED: BlockedEncoding partition calculations
  INFERRED: Semantic execution phases with cited line ranges
  MEASURED: Median, P10, P90, IQR, MAD, block medians
"""

import hashlib
import json
import os
import re
import statistics
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

repo_root_candidate = Path(__file__).resolve().parent.parent.parent
for p in ["/opt/triton-src", str(repo_root_candidate)]:
    if os.path.exists(p) and p not in sys.path:
        sys.path.insert(0, p)

try:
    import modal
    from experiments.tma_reduction_layout.modal_runner import (
        app,
        remote_verify_environment,
        triton_image,
    )
except ImportError:
    modal = None
    app = None
    remote_verify_environment = None
    triton_image = None

from experiments.tma_reduction_layout.analyze_ir import (
    analyze_ptx,
    analyze_ttgir,
    compute_derived_layout_metrics,
    compute_text_hash,
    parse_resource_usage,
)
from experiments.tma_reduction_layout.source_provenance import (
    generate_provenance,
    get_repo_root,
)

REPO_ROOT = get_repo_root()


def calculate_percentile(sorted_data: List[float], percentile: float) -> float:
    """Calculates percentile using standard linear interpolation."""
    if not sorted_data:
        return 0.0
    if len(sorted_data) == 1:
        return sorted_data[0]
    idx = (len(sorted_data) - 1) * percentile
    floor_idx = int(idx)
    ceil_idx = min(floor_idx + 1, len(sorted_data) - 1)
    weight = idx - floor_idx
    return sorted_data[floor_idx] * (1.0 - weight) + sorted_data[ceil_idx] * weight


# ---------------------------------------------------------------------------
# Remote GPU Benchmark Function (Runs on strict H100)
# ---------------------------------------------------------------------------
def _run_tma_benchmark_impl(
    candidates: List[str],
    local_provenance: Dict[str, Any],
) -> str:
    import torch
    import triton
    import triton.language as tl

    # 1. Hardware & Triton provenance & source manifest verification
    env_info = remote_verify_environment(local_provenance)

    # Set scratch allocator required for TMA descriptors
    triton.set_allocator(
        lambda size, align, stream: torch.empty(size, dtype=torch.int8, device="cuda")
    )

    # 2. Benchmark parameters
    B, M, N = 1, 32, 128
    num_warps = 4
    reduce_axis = 1

    torch.manual_seed(42)
    # Fixed input tensor for all candidates
    input_tensor = torch.randn((B, M, N), device="cuda", dtype=torch.bfloat16)
    out_tensor = torch.empty((N,), device="cuda", dtype=torch.float32)

    # Reference PyTorch computation
    ref_out = input_tensor.to(torch.float32).amax(dim=1).squeeze(0)

    stride_b = M * N
    stride_m = N

    results_by_candidate: Dict[str, Any] = {}

    # Define the kernel generator
    def get_kernel():
        @triton.jit
        def kernel(
            a_ptr,
            out_ptr,
            stride_b,
            stride_m,
            B: tl.constexpr,
            M: tl.constexpr,
            N: tl.constexpr,
        ):
            desc = tl.make_tensor_descriptor(
                a_ptr,
                shape=[B, M, N],
                strides=[stride_b, stride_m, 1],
                block_shape=[B, M, N],
            )
            x = desc.load([0, 0, 0])
            x_fp32 = x.to(tl.float32)
            y = tl.max(x_fp32, axis=1)  # shape: [1, 128]
            offs_n = tl.arange(0, N)
            tl.store(out_ptr + offs_n, tl.reshape(y, [N]))

        return kernel

    # Compile and evaluate each candidate
    compiled_kernels = {}
    for cand in candidates:
        print(f"\n[Remote] === Preparing candidate: {cand} ===")
        # Set experiment environment variable
        os.environ["TRITON_TMA_REDUCTION_LAYOUT_EXPERIMENT"] = cand
        os.environ["TRITON_CACHE_DIR"] = f"/tmp/triton_cache_{cand}"

        kernel = get_kernel()

        # Warmup / compilation
        is_legal = True
        compile_err = None
        compiled = None
        try:
            compiled = kernel.warmup(
                input_tensor,
                out_tensor,
                stride_b,
                stride_m,
                B,
                M,
                N,
                grid=(1,),
                num_warps=num_warps,
            )
        except Exception as e:
            is_legal = False
            compile_err = str(e)
            print(f"[Remote] Candidate {cand} failed compilation/validity: {e}")

        if not is_legal or compiled is None:
            results_by_candidate[cand] = {
                "candidate": cand,
                "is_legal": False,
                "error": compile_err,
            }
            continue

        compiled_kernels[cand] = (kernel, compiled)

        # Extract IR and ASM
        ttgir_text = compiled.asm.get("ttgir", "")
        ptx_text = compiled.asm.get("ptx", "")
        llir_text = compiled.asm.get("llir", "")

        # Extract Cubin binary and dump SASS + resource usage
        cubin_bytes = compiled.asm.get("cubin", None)
        if cubin_bytes is None and hasattr(compiled, "kernel"):
            cubin_bytes = compiled.kernel

        cubin_path = Path(f"/tmp/triton_kernel_{cand}.cubin")
        sass_text = ""
        resource_text = ""

        if cubin_bytes is not None:
            cubin_path.write_bytes(cubin_bytes)
            # 1. Dump SASS via cuobjdump -sass
            try:
                sass_text = subprocess.check_output(
                    ["cuobjdump", "-sass", str(cubin_path)],
                    text=True,
                    stderr=subprocess.STDOUT,
                )
            except Exception as e:
                sass_text = f"UNKNOWN (cuobjdump -sass error: {e})"

            # 2. Dump physical resource usage via cuobjdump -res-usage
            try:
                resource_text = subprocess.check_output(
                    ["cuobjdump", "-res-usage", str(cubin_path)],
                    text=True,
                    stderr=subprocess.STDOUT,
                )
            except Exception as e:
                resource_text = f"UNKNOWN (cuobjdump -res-usage error: {e})"
        else:
            sass_text = "UNKNOWN (Cubin binary not found in compiled object)"
            resource_text = "UNKNOWN (Cubin binary not found in compiled object)"

        # Correctness check
        out_tensor.zero_()
        kernel[(1,)](
            input_tensor,
            out_tensor,
            stride_b,
            stride_m,
            B,
            M,
            N,
            num_warps=num_warps,
        )
        torch.cuda.synchronize()

        max_abs_diff = float(torch.max(torch.abs(out_tensor - ref_out)).item())
        is_correct = max_abs_diff < 1e-3
        print(f"[Remote] Candidate {cand}: correctness = {is_correct} (max abs diff: {max_abs_diff})")

        # Extract Triton metadata launch shared memory in bytes
        triton_launch_shared_bytes = getattr(compiled.metadata, "shared", None)

        results_by_candidate[cand] = {
            "candidate": cand,
            "is_legal": True,
            "is_correct": is_correct,
            "max_abs_diff": max_abs_diff,
            "triton_launch_shared_bytes": triton_launch_shared_bytes,
            "ttgir": ttgir_text,
            "ptx": ptx_text,
            "llir": llir_text,
            "sass": sass_text,
            "resource_text": resource_text,
        }

    # Rotated paired timing protocol
    legal_cands = [c for c in candidates if results_by_candidate[c].get("is_legal", False)]
    print(f"\n[Remote] === Running rotated paired timing measurements for: {legal_cands} ===")

    # Warmup all legal kernels
    for _ in range(50):
        for cand in legal_cands:
            k, _ = compiled_kernels[cand]
            k[(1,)](input_tensor, out_tensor, stride_b, stride_m, B, M, N, num_warps=num_warps)
    torch.cuda.synchronize()

    # Timing: Run 10 blocks of 20 iterations each = 200 raw samples per candidate
    # In each block, rotate candidate execution order to eliminate ordering and thermal bias
    cand_samples_us: Dict[str, List[float]] = {c: [] for c in legal_cands}
    cand_block_medians: Dict[str, List[float]] = {c: [] for c in legal_cands}
    block_execution_orders: List[List[str]] = []

    start_event = torch.cuda.Event(enable_timing=True)
    end_event = torch.cuda.Event(enable_timing=True)

    num_blocks = 10
    iters_per_block = 20

    for b in range(num_blocks):
        # Rotate candidate order for this block
        shift = b % len(legal_cands)
        block_order = legal_cands[shift:] + legal_cands[:shift]
        block_execution_orders.append(block_order)

        for cand in block_order:
            k, _ = compiled_kernels[cand]
            block_samples = []
            for _ in range(iters_per_block):
                start_event.record()
                k[(1,)](input_tensor, out_tensor, stride_b, stride_m, B, M, N, num_warps=num_warps)
                end_event.record()
                torch.cuda.synchronize()
                elapsed_us = start_event.elapsed_time(end_event) * 1000.0
                cand_samples_us[cand].append(elapsed_us)
                block_samples.append(elapsed_us)
            cand_block_medians[cand].append(statistics.median(block_samples))

    # Compute comprehensive timing statistics
    for cand in legal_cands:
        samples = cand_samples_us[cand]
        sorted_samples = sorted(samples)
        med = statistics.median(samples)
        mean = statistics.mean(samples)
        p10 = calculate_percentile(sorted_samples, 0.10)
        p90 = calculate_percentile(sorted_samples, 0.90)
        p25 = calculate_percentile(sorted_samples, 0.25)
        p75 = calculate_percentile(sorted_samples, 0.75)
        iqr = p75 - p25
        mad = statistics.median([abs(x - med) for x in samples])

        results_by_candidate[cand]["timing_measurements"] = {
            "num_samples": len(samples),
            "num_blocks": num_blocks,
            "iters_per_block": iters_per_block,
            "raw_samples_us": samples,
            "block_medians_us": cand_block_medians[cand],
            "median_us": med,
            "mean_us": mean,
            "p10_us": p10,
            "p90_us": p90,
            "p25_us": p25,
            "p75_us": p75,
            "iqr_us": iqr,
            "mad_us": mad,
            "min_us": min(samples),
            "max_us": max(samples),
            "distinguishability_note": (
                "For this single-CTA 8-KiB tile benchmark, the current measurement does not "
                "reliably distinguish the candidates' runtime. No performance ranking is claimed."
            ),
        }
        print(
            f"[Remote] Candidate {cand}: median = {med:.2f} us, p10 = {p10:.2f} us, "
            f"p90 = {p90:.2f} us, IQR = {iqr:.2f} us, MAD = {mad:.2f} us"
        )

    final_payload = {
        "status": "PASS",
        "study_case": {
            "shape": [B, M, N],
            "input_dtype": "bf16",
            "acc_dtype": "fp32",
            "op": "max",
            "reduce_axis": reduce_axis,
            "num_warps": num_warps,
        },
        "environment": env_info,
        "local_provenance": local_provenance,
        "timing_protocol": {
            "num_blocks": num_blocks,
            "iters_per_block": iters_per_block,
            "total_samples_per_candidate": num_blocks * iters_per_block,
            "block_execution_orders": block_execution_orders,
        },
        "results": results_by_candidate,
    }

    return json.dumps(final_payload)


if app is not None:
    run_tma_benchmark_remote = app.function(
        image=triton_image,
        gpu="H100!:1",
        timeout=1200,
    )(_run_tma_benchmark_impl)
else:
    run_tma_benchmark_remote = _run_tma_benchmark_impl


# ---------------------------------------------------------------------------
# Audited Semantic Phase Loader (Bound to Artifact Hashes)
# ---------------------------------------------------------------------------
def load_and_validate_audited_phases(
    cand: str, ptx_sha256: str, ttgir_sha256: str
) -> Dict[str, Any]:
    """
    Loads human-audited semantic phase annotations bound to artifact hashes.
    Fails if the compiled PTX or TTGIR SHA256 does not match the audited record.
    """
    annotations_path = (
        REPO_ROOT
        / "experiments"
        / "tma_reduction_layout"
        / "audited_phase_annotations.json"
    )
    if not annotations_path.exists():
        raise FileNotFoundError(
            f"Audited annotations file not found at: {annotations_path}"
        )

    data = json.loads(annotations_path.read_text(encoding="utf-8"))
    cand_ann = data.get("annotations", {}).get(cand)
    if not cand_ann:
        raise KeyError(f"No audited phase annotations found for candidate '{cand}' in {annotations_path}")

    expected_ptx_sha = cand_ann.get("ptx_sha256")
    expected_ttgir_sha = cand_ann.get("ttgir_sha256")

    if expected_ptx_sha != ptx_sha256:
        raise RuntimeError(
            f"CRITICAL: PTX hash mismatch for candidate {cand}!\n"
            f"Expected (audited): {expected_ptx_sha}\n"
            f"Actual (artifact):  {ptx_sha256}\n"
            "Semantic phase line ranges must be re-audited and updated in audited_phase_annotations.json!"
        )

    if expected_ttgir_sha != ttgir_sha256:
        raise RuntimeError(
            f"CRITICAL: TTGIR hash mismatch for candidate {cand}!\n"
            f"Expected (audited): {expected_ttgir_sha}\n"
            f"Actual (artifact):  {ttgir_sha256}\n"
            "Semantic phase line ranges must be re-audited and updated in audited_phase_annotations.json!"
        )

    return cand_ann.get("phases", {})


# ---------------------------------------------------------------------------
# Local Execution & Audited Evidence Generation
# ---------------------------------------------------------------------------
def execute_benchmark() -> Dict[str, Any]:
    print("==================================================")
    print("TMA Reduction Layout Benchmark on H100 (SM90)")
    print("==================================================")

    # 1. Local provenance
    prov = generate_provenance(REPO_ROOT)
    print(f"[Local] Git HEAD: {prov['git_head_sha']} (branch: {prov['branch']})")
    print(f"[Local] Dirty status: {prov['is_dirty']} (diff sha256: {prov['git_diff_head_sha256']})")
    print(f"[Local] Source manifest digest: {prov['source_manifest_sha256']} ({prov['source_manifest_file_count']} files)")

    candidates = ["default", "8", "4", "2", "1"]
    print(f"[Local] Candidates to evaluate: {candidates}")

    # 2. Dispatch to Modal H100
    print("[Local] Dispatching benchmark to Modal H100 (gpu='H100!:1')...")
    with modal.enable_output():
        with app.run():
            raw_json = run_tma_benchmark_remote.remote(candidates, prov)

    payload = json.loads(raw_json)

    # 3. Post-process with audited evidence model
    results_dir = REPO_ROOT / "experiments" / "tma_reduction_layout" / "results"
    artifacts_dir = results_dir / "artifacts"
    artifacts_dir.mkdir(parents=True, exist_ok=True)

    audited_results: Dict[str, Any] = {}

    for cand, res in payload["results"].items():
        if not res.get("is_legal", False):
            audited_results[cand] = {"candidate": cand, "is_legal": False, "error": res.get("error")}
            continue

        ttgir_text = res.get("ttgir", "")
        ptx_text = res.get("ptx", "")
        sass_text = res.get("sass", "")
        resource_text = res.get("resource_text", "")

        # Save artifacts
        ttgir_path = artifacts_dir / f"{cand}.ttgir"
        ptx_path = artifacts_dir / f"{cand}.ptx"
        sass_path = artifacts_dir / f"{cand}.sass"
        res_path = artifacts_dir / f"{cand}.resource.txt"

        ttgir_path.write_text(ttgir_text)
        ptx_path.write_text(ptx_text)
        sass_path.write_text(sass_text)
        res_path.write_text(resource_text)

        # 1. Parse TTGIR
        ttgir_hash = compute_text_hash(ttgir_text)
        ptx_hash = compute_text_hash(ptx_text)
        sass_hash = compute_text_hash(sass_text)
        res_hash = compute_text_hash(resource_text)

        ttgir_info = analyze_ttgir(ttgir_text)
        dest_layout_name = ttgir_info.get("local_load_dest_layout") or "blocked"
        blocked_enc = ttgir_info.get("blocked_encodings", {}).get(dest_layout_name, {})
        shared_alias = ttgir_info.get("local_load_src_shared_layout") or "shared"
        shared_enc = ttgir_info.get("shared_encodings", {}).get(shared_alias, {})

        spt = blocked_enc.get("sizePerThread", [1, 1, 1])
        tpw = blocked_enc.get("threadsPerWarp", [1, 1, 32])
        wpc = blocked_enc.get("warpsPerCTA", [1, 1, 4])
        order = blocked_enc.get("order", [2, 1, 0])
        num_ctas = ttgir_info.get("module_attributes", {}).get("num_ctas", 1)

        # 2. Parse PTX
        ptx_info = analyze_ptx(ptx_text)

        # 3. Parse Physical Resources (distinguishing cuobjdump and Triton launch metadata)
        phys_res = parse_resource_usage(
            resource_text,
            triton_launch_shared_bytes=res.get("triton_launch_shared_bytes"),
        )

        # 4. Compute Derived Metrics
        derived = compute_derived_layout_metrics(
            shape=[1, 32, 128],
            size_per_thread=spt,
            threads_per_warp=tpw,
            warps_per_cta=wpc,
            num_ctas=num_ctas,
            reduce_axis=1,
        )

        # 5. Load and validate SHA-bound audited phases (fails if artifact hashes differ)
        phases = load_and_validate_audited_phases(cand, ptx_hash, ttgir_hash)

        # 6. Assemble into Audited Evidence Model
        timing = res.get("timing_measurements", {})
        candidate_entry = {
            "candidate": cand,
            "raw": {
                "ttgir_sha256": ttgir_hash,
                "ptx_sha256": ptx_hash,
                "sass_sha256": sass_hash,
                "resource_sha256": res_hash,
                "correctness_max_abs_diff": res.get("max_abs_diff"),
                "raw_samples_us": timing.get("raw_samples_us", []),
            },
            "observed": {
                "ttgir": {
                    "local_load_dest_layout": dest_layout_name,
                    "blocked_encoding": blocked_enc,
                    "shared_encoding": shared_enc,
                    "reduce_ops": ttgir_info.get("reduce_ops", []),
                    "module_attributes": ttgir_info.get("module_attributes", {}),
                },
                "ptx": {
                    "initial_local_load": ptx_info.get("initial_local_load", {}),
                    "whole_kernel_opcode_counts": ptx_info.get("whole_kernel_opcode_counts", {}),
                    "observed_shfl_breakdown": ptx_info.get("observed_shfl_breakdown", {}),
                    "virtual_register_declarations": ptx_info.get("virtual_register_declarations", {}),
                },
                "physical_resources": phys_res,
            },
            "derived": derived,
            "inferred": {
                "phases": phases,
            },
            "measured": {
                "is_correct": res.get("is_correct", False),
                "median_us": timing.get("median_us", 0.0),
                "mean_us": timing.get("mean_us", 0.0),
                "p10_us": timing.get("p10_us", 0.0),
                "p90_us": timing.get("p90_us", 0.0),
                "iqr_us": timing.get("iqr_us", 0.0),
                "mad_us": timing.get("mad_us", 0.0),
                "block_medians_us": timing.get("block_medians_us", []),
                "distinguishability_note": timing.get("distinguishability_note", ""),
            },
        }
        audited_results[cand] = candidate_entry

    payload["audited_results"] = audited_results

    # Save complete JSON
    out_json = results_dir / "baseline_results.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    print(f"\n[Local] Complete audited results saved to: {out_json}")

    # Generate the 3 Audited Markdown Tables in baseline_summary_table.md
    generate_summary_tables(payload, results_dir / "baseline_summary_table.md")

    # Generate baseline_evidence.md with instruction annotations
    generate_evidence_doc(payload, results_dir / "baseline_evidence.md")

    return payload


# ---------------------------------------------------------------------------
# Canonical Markdown Summary & Evidence Renderers
# ---------------------------------------------------------------------------
def render_summary(payload: Dict[str, Any]) -> str:
    env = payload.get("environment", {})
    prov = payload.get("local_provenance", {})
    results = payload.get("audited_results", {})

    md_lines = [
        "# TMA Reduction Layout Baseline Characterization: [1, 32, 128] BF16 -> FP32 Max Axis=1",
        "",
        f"- **Hardware**: {env.get('gpu_name')} ({env.get('driver_version')}, CC {env.get('gpu_compute_capability')})",
        f"- **Git HEAD**: `{prov.get('git_head_sha')}` (branch: `{prov.get('branch')}`, dirty: `{prov.get('is_dirty')}`)",
        f"- **Source Manifest**: `{prov.get('source_manifest_sha256')}`",
        f"- **Triton**: `{env.get('triton_version')}` (`{env.get('triton_file')}`)",
        "",
        "---",
        "",
        "## Table 1: Layout Specifications & Derived Partition Structure",
        "",
        "> [!NOTE]",
        "> Attributes `sizePerThread`, `threadsPerWarp`, `warpsPerCTA` are directly **OBSERVED** from the `ttg.local_load` destination `#blocked` layout. Lane partitions, warp partitions, and elements/partition are **DERIVED** via exact formulas from the layout specification. Cross-CTA reduction is absent as `ttg.num-ctas = 1`.",
        "",
        "| Candidate | sizePerThread [OBS] | threadsPerWarp [OBS] | warpsPerCTA [OBS] | numCTAs [OBS] | Lane Parts (M) [DER] | Warp Parts (M) [DER] | CTA Parts (M) [DER] | M Elems/Partition [DER] | Total Elems/Thread [DER] |",
        "| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |",
    ]

    for cand, cdata in results.items():
        if not cdata.get("observed"):
            continue
        obs_ttgir = cdata["observed"]["ttgir"]
        b_enc = obs_ttgir["blocked_encoding"]
        der = cdata["derived"]
        md_lines.append(
            f"| `{cand}` | `{b_enc.get('sizePerThread')}` | `{b_enc.get('threadsPerWarp')}` | `{b_enc.get('warpsPerCTA')}` | "
            f"`{obs_ttgir.get('module_attributes', {}).get('num_ctas', 1)}` | "
            f"{der['lane_partitions_reduce_axis']} | {der['warp_partitions_reduce_axis']} | {der['cta_partitions_reduce_axis']} | "
            f"{der['derived_reduce_elems_per_partition']} | {der['derived_elements_per_thread_total']} |"
        )

    md_lines.extend([
        "",
        "---",
        "",
        "## Table 2: Observed LocalLoad Lowering & Shared Layout Facts",
        "",
        "> [!NOTE]",
        "> Shared memory descriptor layout is `#ttg.nvmma_shared` with `swizzlingByteWidth=128, elementBitWidth=16`. Opcode counts represent whole-kernel occurrences across all phases. Physical registers are extracted via `cuobjdump -res-usage`. For this artifact, 8200 B is consistent with: 8192 B TMA tile storage (1 * 32 * 128 * 2 B) + 8 B mbarrier storage.",
        "| Candidate | Initial LocalLoad Lowering [OBS] | ld.shared (Total) [OBS] | ldmatrix (Total) [OBS] | st.shared (Total) [OBS] | shfl.sync (Setup + Reduct) [OBS] | bar.sync (Total) [OBS] | Physical Regs/Thread [OBS] | cuobjdump SHARED (B) [OBS] | Triton metadata.shared (B) [OBS] |",
        "| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |",
    ])

    for cand, cdata in results.items():
        if not cdata.get("observed"):
            continue
        obs_ptx = cdata["observed"]["ptx"]
        wk = obs_ptx["whole_kernel_opcode_counts"]
        shfl_bk = obs_ptx["observed_shfl_breakdown"]
        init_load = obs_ptx["initial_local_load"]
        phys = cdata["observed"]["physical_resources"]

        load_str = f"{init_load['count']} × `{init_load['instruction']}`" if init_load.get("instruction") else "UNKNOWN"
        shfl_str = f"{wk['shfl_total']} ({shfl_bk['setup_shfl_count']} + {shfl_bk['reduction_region_shfl_count']})"

        regs_val = phys.get("physical_regs_per_thread", {}).get("value", "UNKNOWN")
        cuobj_smem = phys.get("cuobjdump_shared_bytes", {}).get("value", "UNKNOWN")
        triton_smem = phys.get("triton_launch_shared_bytes", {}).get("value", "UNKNOWN")

        md_lines.append(
            f"| `{cand}` | {load_str} | {wk['ld_shared_total']} | {wk['ldmatrix_total']} | {wk['st_shared_total']} | "
            f"{shfl_str} | {wk['bar_sync_total']} | `{regs_val}` | `{cuobj_smem}` | `{triton_smem}` |"
        )

    md_lines.extend([
        "",
        "---",
        "",
        "## Table 3: Empirical Execution Timing on NVIDIA H100 (Single-CTA Tile)",
        "",
        "> [!IMPORTANT]",
        "> **Timing Distinguishability**: For this single-CTA 8-KiB tile benchmark, the current measurement protocol does not establish a reliable performance difference among the candidates. No performance ordering is supported by this run.",
        "",
        "| Candidate | Correctness [OBS] | Median (µs) [MEA] | P10 (µs) [MEA] | P90 (µs) [MEA] | IQR (µs) [MEA] | MAD (µs) [MEA] | Block Medians Range (µs) [MEA] |",
        "| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |",
    ])

    for cand, cdata in results.items():
        if not cdata.get("measured"):
            continue
        m = cdata["measured"]
        blk_meds = m.get("block_medians_us", [])
        blk_range = f"[{min(blk_meds):.2f}, {max(blk_meds):.2f}]" if blk_meds else "N/A"
        correct = "PASS" if m.get("is_correct") else "FAIL"

        md_lines.append(
            f"| `{cand}` | {correct} | **{m.get('median_us', 0.0):.2f}** | {m.get('p10_us', 0.0):.2f} | "
            f"{m.get('p90_us', 0.0):.2f} | {m.get('iqr_us', 0.0):.2f} | {m.get('mad_us', 0.0):.2f} | {blk_range} |"
        )

    return "\n".join(md_lines)


def render_evidence(
    payload: Dict[str, Any], annotations: Optional[Dict[str, Any]] = None
) -> str:
    results = payload.get("audited_results", {})
    md_lines = [
        "# TMA Reduction Layout: Instruction-Level Evidence & Phase Annotations",
        "",
        "This document details the observed instruction ranges and semantic phases for all candidates "
        "compiled from the current commit, providing verified evidence for PTX and SASS codegen.",
        "",
    ]

    for cand, cdata in results.items():
        if not cdata.get("observed"):
            continue
        md_lines.extend([
            f"## Candidate `{cand}`",
            "",
            f"- **TTGIR LocalLoad Layout**: `{cdata['observed']['ttgir']['local_load_dest_layout']}`",
            f"- **Initial LocalLoad**: `{cdata['observed']['ptx']['initial_local_load']}`",
            f"- **Arithmetic Mix**: `{cdata['observed']['ptx']['whole_kernel_opcode_counts']['arithmetic_mix']}`",
            f"- **Virtual Registers**: `{cdata['observed']['ptx']['virtual_register_declarations']}`",
            f"- **Physical Resources**: `{cdata['observed']['physical_resources']}`",
            "",
            "### Semantic Phases (Annotated PTX)",
            "",
            "| Phase | Description | Observed PTX Line Range |",
            "| :--- | :--- | :--- |",
        ])

        phases = {}
        if annotations and "annotations" in annotations and cand in annotations["annotations"]:
            phases = annotations["annotations"][cand].get("phases", {})
        else:
            phases = cdata.get("inferred", {}).get("phases", {})

        for phase_name, p in phases.items():
            if p.get("lines"):
                l0, l1 = p["lines"]
                lines_str = f"Lines {l0}-{l1}" if l0 != l1 else f"Line {l0}"
            else:
                lines_str = p.get("status", "no standalone PTX sequence identified")
            md_lines.append(f"| {phase_name} | {p.get('description', '')} | {lines_str} |")
        md_lines.append("")

    return "\n".join(md_lines)


def generate_summary_tables(payload: Dict[str, Any], output_path: Path):
    content = render_summary(payload)
    output_path.write_text(content, encoding="utf-8")
    print(f"[Local] Audited summary tables saved to: {output_path}")


def generate_evidence_doc(
    payload: Dict[str, Any],
    output_path: Path,
    annotations: Optional[Dict[str, Any]] = None,
):
    if annotations is None:
        annotations_path = (
            REPO_ROOT
            / "experiments"
            / "tma_reduction_layout"
            / "audited_phase_annotations.json"
        )
        if annotations_path.exists():
            annotations = json.loads(annotations_path.read_text(encoding="utf-8"))
    content = render_evidence(payload, annotations)
    output_path.write_text(content, encoding="utf-8")
    print(f"[Local] Audited evidence document saved to: {output_path}")


if __name__ == "__main__":
    execute_benchmark()
