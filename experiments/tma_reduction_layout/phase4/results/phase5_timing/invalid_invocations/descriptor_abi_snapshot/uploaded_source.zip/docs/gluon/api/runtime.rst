Runtime API
===========

.. currentmodule:: triton.experimental.gluon

Runtime
-------

.. autosummary::
    :toctree: generated
    :nosignatures:

    GluonASTSource
    GluonJITFunction
    jit
    constexpr_function
    must_use_result


Host-Side Descriptors
---------------------

.. autosummary::
    :toctree: generated
    :nosignatures:

    nvidia.hopper.TensorDescriptor
    nvidia.hopper.TensorDescriptorIm2Col
    nvidia.blackwell.TensorDescriptor
    amd.cdna5.TensorDescriptor
