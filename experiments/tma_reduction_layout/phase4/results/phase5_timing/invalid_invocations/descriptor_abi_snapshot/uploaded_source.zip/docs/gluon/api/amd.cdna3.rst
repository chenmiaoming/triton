AMD CDNA 3
==========

.. currentmodule:: triton.experimental.gluon.language.amd.cdna3

.. autosummary::
    :toctree: generated
    :nosignatures:

    buffer_load
    buffer_store
    buffer_atomic_add
    buffer_atomic_and
    buffer_atomic_max
    buffer_atomic_min
    buffer_atomic_or
    buffer_atomic_xchg
    buffer_atomic_xor
    get_scaled_upcast_fp4_scale_layout
    mfma
    scaled_upcast
