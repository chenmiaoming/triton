AMD
===

Target-specific Gluon APIs for AMD GPU generations.

Common APIs
-----------

.. currentmodule:: triton.experimental.gluon.language.amd

.. autosummary::
    :toctree: generated
    :nosignatures:

    AMDMFMALayout
    AMDWMMALayout
    slice
    warp_pipeline_stage

GPU Generations
---------------

.. toctree::
   :maxdepth: 1

   CDNA 3 <amd.cdna3>
   CDNA 4 <amd.cdna4>
   CDNA 5 <amd.cdna5>
   RDNA 3 <amd.rdna3>
   RDNA 4 <amd.rdna4>
