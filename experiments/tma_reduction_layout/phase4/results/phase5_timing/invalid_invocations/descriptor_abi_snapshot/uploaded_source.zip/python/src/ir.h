#pragma once
#include "mlir/IR/Builders.h"
#include "mlir/IR/DialectRegistry.h"
#include "triton/Dialect/Triton/IR/Dialect.h"
#include "triton/Tools/Sys/GetEnv.h"
#include <memory>
#include <string>

inline mlir::Attribute
buildCachePolicy(mlir::OpBuilder &builder,
                 mlir::triton::CacheModifier cacheModifier,
                 mlir::triton::EvictionPolicy evictionPolicy =
                     mlir::triton::EvictionPolicy::NORMAL) {
  if (cacheModifier == mlir::triton::CacheModifier::NONE &&
      evictionPolicy == mlir::triton::EvictionPolicy::NORMAL)
    return {};
  return mlir::triton::CachePolicyAttr::get(builder.getContext(), cacheModifier,
                                            evictionPolicy);
}

// A custom op builder that keeps track of the last location
class TritonOpBuilder {
public:
  TritonOpBuilder(mlir::MLIRContext *context) {
    builder = std::make_unique<mlir::OpBuilder>(context);
    lastLoc = std::make_unique<mlir::Location>(builder->getUnknownLoc());
  }

  mlir::OpBuilder &getBuilder() { return *builder; }
  mlir::MLIRContext *getContext() { return builder->getContext(); }

  bool isLineInfoEnabled() { return lineInfoEnabled; }

  void setLastLoc(mlir::Location loc) {
    if (lineInfoEnabled)
      lastLoc = std::make_unique<mlir::Location>(loc);
  }

  void setLastLoc(const std::string &fileName, int line, int column) {
    auto context = builder->getContext();
    setLastLoc(mlir::FileLineColLoc::get(context, fileName, line, column));
  }

  mlir::Location getLastLoc() {
    assert(lastLoc);
    return *lastLoc;
  }

  void setInsertionPointToStart(mlir::Block &block) {
    if (!block.empty())
      setLastLoc(block.begin()->getLoc());
    else
      setLastLoc(getLocForBlock(&block));
    builder->setInsertionPointToStart(&block);
  }

  void setInsertionPointToEnd(mlir::Block &block) {
    if (!block.empty())
      setLastLoc(block.back().getLoc());
    else
      setLastLoc(getLocForBlock(&block));
    builder->setInsertionPointToEnd(&block);
  }

  void setInsertionPointAfter(mlir::Operation &op) {
    setLastLoc(op.getLoc());
    builder->setInsertionPointAfter(&op);
  }

  void restoreInsertionPoint(mlir::OpBuilder::InsertPoint pt) {
    setLastLoc(builder->getUnknownLoc());
    if (pt.isSet()) {
      if (pt.getPoint() != pt.getBlock()->end())
        setLastLoc(pt.getPoint()->getLoc());
      else
        setLastLoc(getLocForBlock(pt.getBlock()));
    }

    builder->restoreInsertionPoint(pt);
  }

  template <typename OpTy, typename... Args> OpTy create(Args &&...args) {
    auto loc = getLastLoc();
    return OpTy::create(*builder, loc, std::forward<Args>(args)...);
  }

  // Overload to create or fold a single result operation.
  template <typename OpTy, typename... Args>
  std::enable_if_t<OpTy::template hasTrait<mlir::OpTrait::OneResult>(),
                   mlir::Value>
  createOrFold(Args &&...args) {
    auto loc = getLastLoc();
    return builder->createOrFold<OpTy>(loc, std::forward<Args>(args)...);
  }

  // Overload to create or fold a zero result operation.
  template <typename OpTy, typename... Args>
  std::enable_if_t<OpTy::template hasTrait<mlir::OpTrait::ZeroResults>(), OpTy>
  createOrFold(Args &&...args) {
    auto loc = getLastLoc();
    return builder->createOrFold<OpTy>(loc, std::forward<Args>(args)...);
  }

private:
  std::unique_ptr<mlir::OpBuilder> builder;
  std::unique_ptr<mlir::Location> lastLoc;
  bool lineInfoEnabled =
      !mlir::triton::tools::getBoolEnv("TRITON_DISABLE_LINE_INFO");

  mlir::Location getLocForBlock(mlir::Block *block) {
    if (auto parentOp = block->getParentOp())
      return parentOp->getLoc();
    return builder->getUnknownLoc();
  }
};
