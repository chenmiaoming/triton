"""CPU-only prototype checks over the exact Stage A current-main image."""
from pathlib import Path
import io
import os
import zipfile
import modal
from experiments.tma_reduction_layout.phase10 import common as c

app=modal.App('triton-phase10-compiler-prototype')
cache=modal.Volume.from_name('triton-build-cache')
volume=modal.Volume.from_name('triton-phase10-evidence')
checkout=Path(os.environ.get('TMA_PHASE10_CHECKOUT','/tmp/triton-tma-current-main'))
native_file=Path('lib/Dialect/TritonGPU/Transforms/OptimizeThreadLocality.cpp')
test_file=Path('test/TritonGPU/optimize-locality.mlir')
image=(modal.Image.from_id('im-qzTUZumWu2JXjWic8K82cZ')
    .add_local_file(checkout/native_file,'/opt/triton-src/'+str(native_file),copy=True)
    .add_local_file(checkout/test_file,'/opt/triton-src/'+str(test_file),copy=True)
    .add_local_file(Path(__file__).with_name('build_prototype.py'),'/opt/phase10-prototype-build.py',copy=True)
    .run_commands('python3 /opt/phase10-prototype-build.py',volumes={'/cache':cache})
    .env({'PYTHONPATH':'/opt/triton-src','PATH':'/opt/phase9-cuda-tools/bin:/usr/local/cuda/bin:/usr/local/bin:/usr/bin:/bin'}))


@app.function(image=image,timeout=1800,volumes={'/evidence':volume},single_use_containers=True)
def check(expected):
    import subprocess
    import sys
    import json
    import hashlib
    import triton._C.libtriton as native
    sys.path.insert(0,'/opt/triton-src/python')
    from build_helpers import get_cmake_dir
    root=Path('/opt/triton-src')
    build=Path(get_cmake_dir())
    out=Path('/evidence/stage_b')/modal.current_function_call_id()
    out.mkdir(parents=True)
    result={'call_id':modal.current_function_call_id(),'status':'OK','checks':[],
        'native_SHA256':hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest(),
        'image_id':os.environ.get('MODAL_IMAGE_ID'),'GPU_timing':False}
    for name,digest in expected.items():
        actual=hashlib.sha256((root/name).read_bytes()).hexdigest()
        assert actual==digest,(name,actual,digest)
        path=out/'source'/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes((root/name).read_bytes())
    for p in Path('/opt/phase10-prototype-build').iterdir():
        if p.is_file():(out/p.name).write_bytes(p.read_bytes())
    # The generated build-tree tests resolve current source and LLVM lit config.
    for tag,command in [('targeted',['lit','-v','test/TritonGPU/optimize-locality.mlir']),
                        ('coalesce',['lit','-v','test/TritonGPU/coalesce.mlir']),
                        ('full_lit',['ninja','check-triton-lit-tests'])]:
        completed=subprocess.run(command,cwd=build,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        (out/(tag+'.log')).write_text(completed.stdout)
        result['checks'].append({'tag':tag,'command':command,'cwd':str(build),'return_code':completed.returncode})
        print(completed.stdout[-12000:],flush=True)
        if completed.returncode:result['status']='FAILED';break
    (out/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    volume.commit()
    stream=io.BytesIO()
    with zipfile.ZipFile(stream,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.rglob('*')):
            if p.is_file():z.write(p,str(p.relative_to(out)))
    return {'result':result,'zip':stream.getvalue()}


@app.local_entrypoint()
def main():
    import uuid
    expected={str(p):c.sha((checkout/p).read_bytes()) for p in [native_file,test_file]}
    root=c.OUT/'stage_b/attempts'/uuid.uuid4().hex
    call=check.spawn(expected)
    c.write_once(root/'dispatch.json',{'call_id':call.object_id,'profile':os.environ.get('MODAL_PROFILE'),'expected_source':expected})
    result=call.get()
    c.write_once(root/'raw_export.zip',result['zip']);c.write_once(root/'return.json',result['result'])
    with zipfile.ZipFile(io.BytesIO(result['zip'])) as z:z.extractall(root/'export')
    assert result['result']['status']=='OK','Native/lit failure archived'
    c.write_once(c.OUT/'stage_b/accepted.json',{'attempt':str(root.relative_to(c.ROOT)),'source':expected,'result':result['result']})
