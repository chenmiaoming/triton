"""Layout-explicit translations of the pinned scale-swizzle/AWQ kernels.

The source functions and their original license notices are retained under
sources/quant_*.  G0 is admissible only after the full native-code/ABI gate.
Index expressions use AutoLayout until an explicit memory-boundary encoding;
values have concrete layouts.  No compiler pipeline is modified.
"""
from triton.experimental import gluon
from triton.experimental.gluon import language as gl


@gluon.jit
def triton_scale_swizzle(
    scale_ptr, scale_rows, scale_cols, output_ptr, input_row_stride,
    input_col_stride, output_block_stride, BLOCK_ROWS: gl.constexpr,
    BLOCK_COLS: gl.constexpr, LINPUT: gl.constexpr, LOUT: gl.constexpr,
):
    pid_row = gl.program_id(0)
    pid_col = gl.program_id(1)
    rows = gl.arange(0, BLOCK_ROWS)[:, None]
    cols = gl.arange(0, BLOCK_COLS)[None, :]
    start_row = pid_row * BLOCK_ROWS
    start_col = pid_col * BLOCK_COLS
    global_rows = start_row + rows
    global_cols = start_col + cols
    mask = (global_rows < scale_rows) & (global_cols < scale_cols)
    input_pointer = gl.set_auto_layout(
        scale_ptr + global_rows*input_row_stride + global_cols*input_col_stride,
        LINPUT)
    input_scales = gl.load(input_pointer, mask=gl.set_auto_layout(mask, LINPUT), other=0.0)
    r_div_32 = rows // 32
    r_mod_32 = rows % 32
    dest_indices = r_mod_32*16 + r_div_32*4 + cols
    dest_indices_flat = gl.reshape(dest_indices, (BLOCK_ROWS*BLOCK_COLS,))
    scales_flat = gl.reshape(input_scales, (BLOCK_ROWS*BLOCK_COLS,))
    LOCAL_NUMEL = BLOCK_ROWS*BLOCK_COLS
    block_offset = pid_col*LOCAL_NUMEL + pid_row*output_block_stride
    output_pointer = gl.set_auto_layout(output_ptr + block_offset + dest_indices_flat, LOUT)
    gl.store(output_pointer, gl.convert_layout(scales_flat, LOUT))


@gluon.jit
def _interleave(a, b):
    # Exact join/reshape semantics of triton.language.standard.interleave.
    joined = gl.join(a, b)
    return gl.reshape(joined, joined.shape[:-2] + [2*joined.shape[-2]])


@gluon.jit
def awq_dequantize_kernel(
    qweight_ptr, scales_ptr, zeros_ptr, group_size, result_ptr, num_cols,
    num_rows, BLOCK_SIZE_X: gl.constexpr, BLOCK_SIZE_Y: gl.constexpr,
    LQ: gl.constexpr, LZ: gl.constexpr, LS: gl.constexpr,
    LEXP: gl.constexpr, LOUT: gl.constexpr,
):
    pid_x = gl.program_id(0)
    pid_y = gl.program_id(1)
    offsets_y = pid_y*BLOCK_SIZE_Y + gl.arange(0, BLOCK_SIZE_Y)
    offsets_x = pid_x*BLOCK_SIZE_X + gl.arange(0, BLOCK_SIZE_X)
    offsets = num_cols*offsets_y[:, None] + offsets_x[None, :]
    masks_y = offsets_y < num_rows
    masks_x = offsets_x < num_cols
    masks = masks_y[:, None] & masks_x[None, :]
    result_offsets_y = pid_y*BLOCK_SIZE_Y + gl.arange(0, BLOCK_SIZE_Y)
    result_offsets_x = pid_x*BLOCK_SIZE_X*8 + gl.arange(0, BLOCK_SIZE_X*8)
    result_offsets = 8*num_cols*result_offsets_y[:, None] + result_offsets_x[None, :]
    result_masks_y = result_offsets_y < num_rows
    result_masks_x = result_offsets_x < num_cols*8
    result_masks = result_masks_y[:, None] & result_masks_x[None, :]
    iweights = gl.load(gl.set_auto_layout(qweight_ptr + offsets, LQ),
        gl.set_auto_layout(masks, LQ), 0.0)
    iweights = _interleave(iweights, iweights)
    iweights = _interleave(iweights, iweights)
    iweights = _interleave(iweights, iweights)
    iweights = gl.convert_layout(iweights, LEXP)
    reverse_awq_order_tensor = (
        (gl.arange(0, 2)*4)[None, :] + gl.arange(0, 4)[:, None]
    ).reshape(8)
    shifts = reverse_awq_order_tensor*4
    shifts = shifts[None, :].broadcast_to((BLOCK_SIZE_Y*BLOCK_SIZE_X, 8))
    shifts = gl.reshape(shifts, (BLOCK_SIZE_Y, BLOCK_SIZE_X*8))
    shifts = gl.set_auto_layout(shifts, LEXP)
    iweights = (iweights >> shifts) & 0xF
    zero_offsets_y = pid_y*BLOCK_SIZE_Y//group_size + gl.arange(0, 1)
    zero_offsets_x = pid_x*BLOCK_SIZE_X + gl.arange(0, BLOCK_SIZE_X)
    zero_offsets = num_cols*zero_offsets_y[:, None] + zero_offsets_x[None, :]
    zero_masks_y = zero_offsets_y < num_rows//group_size
    zero_masks_x = zero_offsets_x < num_cols
    zero_masks = zero_masks_y[:, None] & zero_masks_x[None, :]
    zeros = gl.load(gl.set_auto_layout(zeros_ptr + zero_offsets, LZ),
        gl.set_auto_layout(zero_masks, LZ), 0.0)
    zeros = _interleave(zeros, zeros)
    zeros = _interleave(zeros, zeros)
    zeros = _interleave(zeros, zeros)
    zeros = zeros.broadcast_to((BLOCK_SIZE_Y, BLOCK_SIZE_X*8))
    zeros = gl.convert_layout(zeros, LEXP)
    zeros = (zeros >> shifts) & 0xF
    scale_offsets_y = pid_y*BLOCK_SIZE_Y//group_size + gl.arange(0, 1)
    scale_offsets_x = pid_x*BLOCK_SIZE_X*8 + gl.arange(0, BLOCK_SIZE_X*8)
    scale_offsets = num_cols*8*scale_offsets_y[:, None] + scale_offsets_x[None, :]
    scale_masks_y = scale_offsets_y < num_rows//group_size
    scale_masks_x = scale_offsets_x < num_cols*8
    scale_masks = scale_masks_y[:, None] & scale_masks_x[None, :]
    scales = gl.load(gl.set_auto_layout(scales_ptr + scale_offsets, LS),
        gl.set_auto_layout(scale_masks, LS), 0.0)
    # U narrows the integer difference before redistributing it to the output
    # encoding, and redistributes the scale row before its row broadcast.
    # Keeping those boundaries is part of the G0 code-equivalence contract.
    scales = gl.convert_layout(scales, LOUT)
    scales = scales.broadcast_to((BLOCK_SIZE_Y, BLOCK_SIZE_X*8))
    integer_difference = iweights - zeros
    difference = integer_difference.to(scales.dtype)
    difference = gl.convert_layout(difference, LOUT)
    iweights = difference*scales
    iweights = iweights.to(result_ptr.type.element_ty)
    gl.store(gl.set_auto_layout(result_ptr + result_offsets, LOUT),
        gl.convert_layout(iweights, LOUT), gl.set_auto_layout(result_masks, LOUT))


def layout_constants(case, plan, variant='G0'):
    from ..operator_gpu.layout_parsing import instantiate
    if isinstance(variant, str):
        assert variant == 'G0', variant
        current = plan
    else:
        current = {**plan, **variant.get('plan_override', {})}
    names = {'LINPUT':'input', 'LOUT':'output'} if case['family']=='N01' else {
        'LQ':'qweight', 'LZ':'zeros', 'LS':'scales', 'LEXP':'expanded', 'LOUT':'output'}
    return {name:instantiate(current[key], gl) for name,key in names.items()}



def variants(case, plan):
    from .quant_adapter import variants as choices
    return choices(case, plan)
