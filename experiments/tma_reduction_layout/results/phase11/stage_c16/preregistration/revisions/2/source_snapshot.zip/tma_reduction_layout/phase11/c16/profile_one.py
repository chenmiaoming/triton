"""Application-replay child; recreate cache state before one profiled launch."""
import argparse
import ctypes as C
import json
import sys
import torch
from experiments.tma_reduction_layout.phase11.c16 import common as c
from experiments.tma_reduction_layout.phase11.c16 import runtime as r


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', required=True)
    p.add_argument('--metadata', required=True)
    p.add_argument('--protocol', required=True)
    p.add_argument('--tag', required=True)
    p.add_argument('--cache', choices=['warm', 'cold'], required=True)
    args = p.parse_args()
    protocol = c.read(args.protocol)
    c.verify_sources(protocol)
    meta = c.read(args.metadata)[args.tag]
    assert meta['family'] in ('FULL', 'TMA')
    torch.cuda.init()
    driver = r.Driver()
    x, out, scratch, eviction, stream, kernels, params = r.prepare(torch, driver, args.root, {args.tag: meta}, protocol)
    kernel = kernels[args.tag]
    owners, values, serialized = params[args.tag, 0]
    correctness = r.check(torch, driver, kernel, meta['full_grid'], 0, values, out, stream)
    if args.cache == 'cold':
        eviction.zero_()
    else:
        for _ in range(3):
            kernel.guard()
            kernel.launch(meta['full_grid'], values, stream)
    driver.call('cuStreamSynchronize', [C.c_void_p], stream)
    kernel.guard()
    driver.call('cuProfilerStart', [])
    kernel.launch(meta['full_grid'], values, stream)
    driver.call('cuStreamSynchronize', [C.c_void_p], stream)
    driver.call('cuProfilerStop', [])
    assert not any(m == 'triton' or m.startswith('triton.') for m in sys.modules)
    print('PROFILE_BINDING ' + json.dumps({'tag': args.tag, 'cache': args.cache,
          'binding': kernel.binding(), 'parameters': serialized, 'correctness': correctness,
          'protocol_SHA256': c.sha(c.encode(protocol)), 'Triton_imported': False,
          'environment': driver.environment()}), flush=True)


if __name__ == '__main__':
    main()
