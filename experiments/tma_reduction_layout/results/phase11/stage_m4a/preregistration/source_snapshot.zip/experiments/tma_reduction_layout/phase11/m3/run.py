"""CPU preflight and bounded H100 frozen-binary jobs using existing caches."""
import os
from pathlib import Path
import modal
from experiments.tma_reduction_layout.phase11.m3 import common as c

SNAPSHOT = Path('/tmp/tma-phase11-m3-snapshot')
app = modal.App('triton-phase11-m3-output-policy')


def image_for(identity):
    environment = {'PYTHONPATH': '/opt/triton-src',
                   'TRITON_CACHE_DIR': '/cache/phase11-upstream20d9-kernel-cache'}
    if identity == c.BASE_IMAGE:
        environment['PATH'] = '/opt/phase9-cuda-tools/bin:/usr/local/cuda/bin:/usr/local/bin:/usr/bin:/bin'
    return modal.Image.from_id(identity).env(environment).add_local_dir(
        SNAPSHOT/'experiments', '/opt/triton-src/experiments', copy=True,
        ignore=['**/__pycache__/**', '**/*.pyc'])


image = image_for(c.BASE_IMAGE)
tools_image = image_for(c.TOOLS_IMAGE)
cache = modal.Volume.from_name('triton-build-cache')
evidence = modal.Volume.from_name('triton-phase11-evidence')


@app.function(image=image, cpu=8, memory=16384, timeout=3600,
              volumes={'/cache': cache, '/evidence': evidence}, include_source=False)
def preflight(protocol, reuse_blob):
    import subprocess
    import traceback
    import triton
    import triton._C.libtriton as native
    from triton.backends.compiler import GPUTarget
    from triton.experimental import gluon
    from triton.experimental.gluon import language as gl
    from experiments.tma_reduction_layout.phase11.m3.kernels import full_output
    c.verify_sources(protocol)
    root = Path('/evidence/stage_m3/cpu_preflight')/modal.current_function_call_id()
    root.mkdir(parents=True, exist_ok=False)
    c.extract(reuse_blob, root)
    result = {'status': 'FAILED', 'GPU_allocated': False, 'metadata': {},
              'call_id': modal.current_function_call_id(), 'new_compiles': 0, 'reused': 0,
              'protocol_SHA256': c.sha(c.encode(protocol))}

    def command(*argv):
        return subprocess.check_output(argv, text=True, stderr=subprocess.STDOUT)

    try:
        result['native_SHA256'] = c.sha(Path(native.__file__).read_bytes())
        assert result['native_SHA256'] == protocol['baseline']['native_SHA256']
        result['ccache_before'] = command('ccache', '--print-stats')
        for case in protocol['cases']:
            folder = root/case['tag'].replace(':', '/')
            if case.get('reuse_source'):
                assert c.sha((folder/'kernel.cubin').read_bytes()) == case['cubin_SHA256']
                meta = case
                result['reused'] += 1
            else:
                w = case['num_warps']
                shared = gl.NVMMASharedLayout(**case['shared_layout'])
                constants = {'BM':case['M'],'BN':case['N'],'W':w,'S':shared,
                    'L':gl.BlockedLayout(**case['layout']),'OUTPUT':case['output_policy']}
                signature = {'desc':f'tensordesc<bf16[1,{case["M"]},{case["N"]}],{shared}>',
                             'out':'*fp32', **{key:'constexpr' for key in constants}}
                source = gluon.GluonASTSource(full_output,signature,constants,{(1,):[['tt.divisibility',16]]})
                compiled = triton.compile(source,target=GPUTarget('cuda',90,32),options={'num_warps':w})
                for ext in ('glir','ttgir','llir','ptx','cubin'):
                    value = compiled.asm[ext]
                    c.write_once(folder/('kernel.'+ext),value if isinstance(value,bytes) else value.encode())
                for ext,flag in (('sass','-sass'),('resource.txt','-res-usage')):
                    c.write_once(folder/('kernel.'+ext),command('cuobjdump',flag,str(folder/'kernel.cubin')).encode())
                c.write_once(folder/'kernel.lines.sass',command('nvdisasm','-g','-c',str(folder/'kernel.cubin')).encode())
                meta = {**case,'cubin_SHA256':c.sha(compiled.asm['cubin']),
                    'function_name':compiled.name,'dynamic_smem_bytes':compiled.metadata.shared,
                    'global_scratch_size':compiled.metadata.global_scratch_size,
                    'tensordesc_meta':compiled.metadata.tensordesc_meta,'compile_cache_key':compiled.hash}
                result['new_compiles'] += 1
            c.write_once(folder/'m3_metadata.json', meta)
            result['metadata'][case['tag']] = meta
            print('M3 CPU',case['tag'],'REUSED' if case.get('reuse_source') else 'COMPILED',flush=True)
        result['ccache_after'] = command('ccache', '--print-stats')
        assert result['ccache_before'] == result['ccache_after']
        result['status'] = 'OK'
    except Exception:
        result['error'] = traceback.format_exc()
        print(result['error'], flush=True)
    c.write_once(root/'result.json', result)
    cache.commit()
    evidence.commit()
    return c.archive(root)


@app.function(image=image, gpu='H100!:1', timeout=2400,
              volumes={'/evidence': evidence}, single_use_containers=True, include_source=False)
def collect(protocol, metadata, payload):
    from experiments.tma_reduction_layout.phase11.m3.runtime import eligibility
    c.verify_sources(protocol)
    root = Path('/tmp')/modal.current_function_call_id()
    c.extract(payload, root)
    result = eligibility(protocol, metadata, root)
    result.update(call_id=modal.current_function_call_id(), protocol_SHA256=c.sha(c.encode(protocol)),
                  payload_SHA256=c.sha(payload))
    c.write_once(Path('/evidence/stage_m3/eligibility')/modal.current_function_call_id()/'raw.json', result)
    evidence.commit()
    return result


@app.function(image=image, gpu='H100!:1', timeout=5400,
              volumes={'/evidence': evidence}, single_use_containers=True, include_source=False)
def timing(invocation, protocol, gate, payload):
    from experiments.tma_reduction_layout.phase11.m3.runtime import execute
    c.verify_sources(protocol)
    result = execute(invocation, protocol, gate, payload, modal.current_function_call_id())
    c.write_once(Path('/evidence/stage_m3/timing')/modal.current_function_call_id()/'raw.json', result)
    evidence.commit()
    return result


@app.function(image=tools_image, gpu='H100!:1', timeout=3000,
              volumes={'/evidence': evidence}, single_use_containers=True, include_source=False)
def profiles(protocol, gate, payload, group_index):
    import subprocess
    import sys
    import traceback
    c.verify_sources(protocol)
    root = Path('/evidence/stage_m3/profiles')/modal.current_function_call_id()
    root.mkdir(parents=True, exist_ok=False)
    artifacts = root/'artifacts'
    c.extract(payload, artifacts)
    group = gate['profile_groups'][group_index]
    result = {'status': 'FAILED', 'group': group_index, 'records': [],
              'call_id': modal.current_function_call_id(), 'protocol_SHA256': c.sha(c.encode(protocol)),
              'formal_timing': False}

    def command(path, argv):
        try:
            process = subprocess.run(argv, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=1800)
            value = {'argv': argv, 'returncode': process.returncode, 'output': process.stdout}
        except Exception as error:
            value = {'argv': argv, 'returncode': 'EXECUTION_FAILURE', 'output': repr(error)}
        c.write_once(path, value)
        return value

    try:
        command(root/'ncu_version.json', ['ncu', '--version'])
        for mode in ('software', 'hardware'):
            cells = []
            for tag in group:
                meta = gate['metadata'][tag]
                if mode == 'software':
                    cells.append({'tag':tag,'K':1,'grid':1,'q':'natural'})
                else:
                    for q in protocol['profiles']['q_conditions']:
                        reservation = gate['resources'][tag]['reservations'][q]
                        if q != 'natural' and not reservation.get('feasible'):
                            continue
                        grid = 1 if meta.get('profile_only') else (8192//meta['M'])*(8192//meta['N'])
                        cells.append({'tag':tag,'K':1,'grid':grid,'q':q})
            folder = root/mode
            folder.mkdir()
            job = {'cells': cells, 'metadata': {tag: gate['metadata'][tag] for tag in group}}
            c.write_once(folder/'job.json', job)
            flags = ['--section', 'InstructionStats'] if mode == 'software' else ['--metrics', ','.join(protocol['profiles']['metrics'])]
            value = command(folder/'collect.json', ['ncu', '--replay-mode', 'kernel', '--cache-control', 'none',
                '--clock-control', 'none', '--profile-from-start', 'off', *flags,
                '--export', str(folder/'report'), sys.executable, '-m',
                'experiments.tma_reduction_layout.phase11.m3.profile_one', '--root', str(artifacts), '--job', str(folder/'job.json')])
            assert value['returncode'] == 0, value['output'][-6000:]
            assert (folder/'report.ncu-rep').exists()
            value = command(folder/'import.json', ['ncu', '--import', str(folder/'report.ncu-rep'), '--page', 'raw',
                             '--csv', '--print-units', 'base', '--print-fp'])
            assert value['returncode'] == 0, value['output'][-3000:]
            if mode == 'software':
                value = command(folder/'source.json', ['ncu', '--import', str(folder/'report.ncu-rep'),
                                 '--page', 'source', '--print-source', 'sass', '--csv'])
                assert value['returncode'] == 0, value['output'][-3000:]
            result['records'].append({'mode': mode, 'launches': len(cells),
                                      'report_SHA256': c.sha((folder/'report.ncu-rep').read_bytes())})
            print('M3 NCU group', group_index, mode, 'PASS', len(cells), flush=True)
        result['status'] = 'OK'
    except Exception:
        result['error'] = traceback.format_exc()
        print(result['error'], flush=True)
    c.write_once(root/'result.json', result)
    # CUBIN payload is already preserved in CPU preflight and its archive.
    import shutil
    shutil.rmtree(artifacts)
    evidence.commit()
    return c.archive(root)


def save_return(folder, call):
    try:
        result=call.get()
    except Exception as error:
        c.write_once(folder/'retrieval_failure.json',{'call_id':call.object_id,'error':repr(error)})
        raise
    if isinstance(result,bytes):
        c.write_once(folder/'raw_export.zip',result)
        c.extract(result,folder/'export')
        status=c.read(folder/'export/result.json')['status']
    else:
        c.write_once(folder/'raw.json',result)
        status=result['status']
    print('M3 return',folder.name,status,flush=True)
    return status


@app.local_entrypoint()
def main(action: str='preflight',attempt: int=1,invocation: int=1,group: int=0):
    from concurrent.futures import ThreadPoolExecutor
    protocol=c.protocol()
    c.protect_prior()
    c.verify_sources(protocol)
    assert 1<=attempt<=3
    assert os.environ.get('MODAL_PROFILE')=='chenmiaoming'
    jobs=[]
    if action=='preflight':
        jobs=[(c.OUT/'cpu_preflight'/f'attempt_{attempt}',preflight,
               (protocol,(c.OUT/'preregistration/reuse.zip').read_bytes()))]
    else:
        compiled=c.read(c.OUT/'compile_gate.json')
        payload=(c.OUT/'compiled_payload.zip').read_bytes()
        if action=='collect':
            jobs=[(c.OUT/'eligibility'/f'attempt_{attempt}',collect,(protocol,compiled['metadata'],payload))]
        else:
            gate=c.read(c.OUT/'artifact_gate.json');assert gate['status']=='OK'
            if action in ('profiles','profiles_all'):
                indices=range(len(gate['profile_groups'])) if action=='profiles_all' else [group]
                jobs=[(c.OUT/'profiles'/f'group_{g}'/f'attempt_{attempt}',profiles,
                       (protocol,gate,payload,g)) for g in indices]
            else:
                assert action in ('timing','timing_all')
                indices=range(1,protocol['timing']['workers']+1) if action=='timing_all' else [invocation]
                jobs=[(c.OUT/'timing'/f'invocation_{i}',timing,(i,protocol,gate,payload)) for i in indices]
    calls=[]
    for folder,function,args in jobs:
        assert not folder.exists(),folder
        call=function.spawn(*args)
        c.write_once(folder/'dispatch.json',{'call_id':call.object_id,'profile':os.environ['MODAL_PROFILE'],
            'action':action,'protocol_SHA256':c.sha(c.encode(protocol))})
        calls.append((folder,call))
    with ThreadPoolExecutor(max_workers=len(calls)) as executor:
        statuses=list(executor.map(lambda pair:save_return(*pair),calls))
    assert all(s=='OK' for s in statuses),statuses


if __name__=='__main__':
    raise SystemExit('Use modal run --profile chenmiaoming -m experiments.tma_reduction_layout.phase11.m3.run')
