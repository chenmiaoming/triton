# M4A — 加载服务与同步依赖对照

主要结果与解释见 [FINDINGS.md](FINDINGS.md)，下文保留完整设计、表格与限制。

本阶段为开发域机制实验，旧选择器与旧报告保持不变，没有新选择器拟合或盲测记分。
固定 `20d9d98fead78c2f65e1b3ba5a7881d86a836dad`；复用既有 compiler/tools image、ccache 与 kernel cache，native rebuild=0。
36 个逻辑程序，新增 27、复用 9，CPU 拒绝 0。
三种输入、完整 2 MiB 输入所对应的全部输出与尾部 canary 共 108 项通过。
三名独立 H100 worker，7560 个正式 CUDA Graph 事件样本；NCU 原始报告 8 份，全部本地 CPU 重导入核对。

主指标是 128/256/384 MiB 连续 BF16 输入对应的 loop-free FULL 服务斜率，单位 ns/tile/SM；128 MiB 原始 µs 单列。
3 visits，每次 2 warmup+4 samples，配对随机顺序，不因输赢追加重复。每个 worker 内先以中位数作三点斜率，再比较同 worker 条件。
下文区间是三个配对 worker 的均值 ± t(2,0.975)×SEM，属于探索性逐项区间，未校正多重比较。
q 是占用 API 给出的 padding 驻留容量，不能当作实际同时活跃的 CTA 数。

## 1. H4 的检验口径

检验“加载冲突/吞吐与跨 warp 同步依赖有不同驻留响应”，不是提前认定 H4 已成立。
寄存器布局、native 输出与 max 源程序固定，只改变 NVMMASharedLayout 的 128/64/32/0B swizzle，另配同 swizzle 的 T_control。
36 个程序都通过编译和 GPU 正确性，原 q=2/4/8 曲线直接引用 M2/M3；新配对计时只做 q=1/natural，NCU 补 q=1/2/4/natural。
静态 64 个 ML 冲突的消除预测，见 CPU 准备的 operation_plans_v2.json；真实指令分组、MR 和资源变化在本阶段核对。

## 2. within−N-first 的完整程序差分

负数表示 within 更快。只在双方实际容量相同的 q 档配对；全部 natural 时间与各自容量见 analysis.json。

| geometry | shared swizzle B | q_cap | within−NF ns | paired t95 ns |
| --- | --- | --- | --- | --- |
| [32, 64, 8] | 128 | 1 | -62.047 | [-66.253, -57.841] |
| [32, 64, 8] | 128 | 8 | -5.124 | [-7.483, -2.765] |
| [32, 64, 8] | 64 | 1 | -73.455 | [-74.829, -72.081] |
| [32, 64, 8] | 64 | 8 | -7.315 | [-10.281, -4.350] |
| [32, 64, 8] | 32 | 1 | -102.749 | [-104.489, -101.009] |
| [32, 64, 8] | 32 | 8 | -29.487 | [-31.530, -27.445] |
| [32, 64, 8] | 0 | 1 | +43.248 | [+42.287, +44.209] |
| [32, 64, 8] | 0 | 8 | +60.919 | [+58.191, +63.647] |
| [32, 128, 4] | 128 | 1 | -25.953 | [-31.996, -19.910] |
| [32, 128, 4] | 128 | 16 | -1.375 | [-4.498, +1.748] |
| [32, 128, 4] | 64 | 1 | -93.092 | [-94.934, -91.250] |
| [32, 128, 4] | 64 | 16 | +0.988 | [-3.101, +5.078] |
| [32, 128, 4] | 32 | 1 | -128.262 | [-132.725, -123.798] |
| [32, 128, 4] | 32 | 16 | -1.461 | [-7.386, +4.464] |
| [32, 128, 4] | 0 | 1 | -16.951 | [-18.873, -15.030] |
| [32, 128, 4] | 0 | 16 | -0.387 | [-3.160, +2.387] |
| [16, 256, 8] | 128 | 1 | -32.398 | [-34.426, -30.371] |
| [16, 256, 8] | 128 | 8 | -1.160 | [-5.277, +2.957] |
| [16, 256, 8] | 64 | 1 | -102.137 | [-106.289, -97.985] |
| [16, 256, 8] | 64 | 8 | +0.064 | [-7.573, +7.702] |
| [16, 256, 8] | 32 | 1 | -136.834 | [-143.961, -129.707] |
| [16, 256, 8] | 32 | 8 | -0.924 | [-5.468, +3.620] |
| [16, 256, 8] | 0 | 1 | -36.094 | [-37.940, -34.247] |
| [16, 256, 8] | 0 | 8 | -0.258 | [-4.044, +3.528] |

## 3. 改变 swizzle 的配对效应与隔离程度

下表是同一寄存器布局、同一消费者相对 128B swizzle 的服务时间差。
MR 相同列只核对源行归属的 opcode 类及动态次数，不代表寄存器操作数、排程或所有依赖均相同。
寄存器不同时也保留数据，在受控 q=1 下消除容量差异，但不将其伪装成机器码完全相同的单变量延迟。

| 程序 | q_cap | 相对 sw128 ns | paired t95 ns | MR opcode/count 相同 | regs 相同 |
| --- | --- | --- | --- | --- | --- |
| M32_N64_w8:vec2:n_first:sw64:native:ONE_FULL | 1 | +16.425 | [+14.972, +17.878] | False | True |
| M32_N64_w8:vec2:n_first:sw64:native:ONE_FULL | 8 | +3.287 | [-0.326, +6.901] | False | True |
| M32_N64_w8:vec2:n_first:sw32:native:ONE_FULL | 1 | +51.874 | [+50.811, +52.937] | False | False |
| M32_N64_w8:vec2:n_first:sw32:native:ONE_FULL | 8 | +27.382 | [+24.202, +30.562] | False | False |
| M32_N64_w8:vec2:n_first:sw0:native:ONE_FULL | 1 | +5.844 | [+3.859, +7.828] | True | False |
| M32_N64_w8:vec2:n_first:sw0:native:ONE_FULL | 8 | +0.032 | [-1.911, +1.975] | True | False |
| M32_N64_w8:vec2:within:sw64:native:ONE_FULL | 1 | +5.017 | [+2.206, +7.827] | True | True |
| M32_N64_w8:vec2:within:sw64:native:ONE_FULL | 8 | +1.096 | [+0.172, +2.019] | True | True |
| M32_N64_w8:vec2:within:sw32:native:ONE_FULL | 1 | +11.172 | [+7.820, +14.523] | True | True |
| M32_N64_w8:vec2:within:sw32:native:ONE_FULL | 8 | +3.019 | [+0.894, +5.143] | True | True |
| M32_N64_w8:vec2:within:sw0:native:ONE_FULL | 1 | +111.139 | [+108.506, +113.771] | True | False |
| M32_N64_w8:vec2:within:sw0:native:ONE_FULL | 8 | +66.075 | [+63.107, +69.043] | True | False |
| M32_N128_w4:vec2:n_first:sw64:native:ONE_FULL | 1 | +30.787 | [+27.058, +34.516] | False | False |
| M32_N128_w4:vec2:n_first:sw64:native:ONE_FULL | 16 | +0.838 | [-4.358, +6.034] | False | False |
| M32_N128_w4:vec2:n_first:sw32:native:ONE_FULL | 1 | +145.943 | [+140.192, +151.695] | False | False |
| M32_N128_w4:vec2:n_first:sw32:native:ONE_FULL | 16 | +27.715 | [+22.720, +32.710] | False | False |
| M32_N128_w4:vec2:n_first:sw0:native:ONE_FULL | 1 | -25.115 | [-29.850, -20.381] | False | True |
| M32_N128_w4:vec2:n_first:sw0:native:ONE_FULL | 16 | -2.020 | [-7.139, +3.100] | False | True |
| M32_N128_w4:vec2:within:sw64:native:ONE_FULL | 1 | -36.352 | [-40.137, -32.566] | True | True |
| M32_N128_w4:vec2:within:sw64:native:ONE_FULL | 16 | +3.201 | [-1.474, +7.876] | True | True |
| M32_N128_w4:vec2:within:sw32:native:ONE_FULL | 1 | +43.635 | [+40.160, +47.110] | True | True |
| M32_N128_w4:vec2:within:sw32:native:ONE_FULL | 16 | +27.629 | [+22.862, +32.396] | True | True |
| M32_N128_w4:vec2:within:sw0:native:ONE_FULL | 1 | -16.113 | [-20.472, -11.755] | True | True |
| M32_N128_w4:vec2:within:sw0:native:ONE_FULL | 16 | -1.031 | [-3.763, +1.700] | True | True |
| M16_N256_w8:vec2:n_first:sw64:native:ONE_FULL | 1 | +28.145 | [+21.164, +35.125] | False | False |
| M16_N256_w8:vec2:n_first:sw64:native:ONE_FULL | 8 | -0.516 | [-2.874, +1.843] | False | False |
| M16_N256_w8:vec2:n_first:sw32:native:ONE_FULL | 1 | +153.012 | [+145.966, +160.057] | False | False |
| M16_N256_w8:vec2:n_first:sw32:native:ONE_FULL | 8 | +39.939 | [+34.765, +45.114] | False | False |
| M16_N256_w8:vec2:n_first:sw0:native:ONE_FULL | 1 | -23.955 | [-27.450, -20.460] | False | False |
| M16_N256_w8:vec2:n_first:sw0:native:ONE_FULL | 8 | -0.301 | [-6.872, +6.271] | False | False |
| M16_N256_w8:vec2:within:sw64:native:ONE_FULL | 1 | -41.594 | [-49.837, -33.350] | True | False |
| M16_N256_w8:vec2:within:sw64:native:ONE_FULL | 8 | +0.709 | [-5.599, +7.017] | True | False |
| M16_N256_w8:vec2:within:sw32:native:ONE_FULL | 1 | +48.576 | [+43.888, +53.265] | True | True |
| M16_N256_w8:vec2:within:sw32:native:ONE_FULL | 8 | +40.176 | [+39.842, +40.509] | True | True |
| M16_N256_w8:vec2:within:sw0:native:ONE_FULL | 1 | -27.650 | [-31.679, -23.622] | True | True |
| M16_N256_w8:vec2:within:sw0:native:ONE_FULL | 8 | +0.602 | [-5.199, +6.402] | True | True |

## 4. 硬件计数与结论边界

计数表见下节及 diagnostics.json：包含全部 shared load/store 波前、bank conflict、动态 LDS/STS/SHFL/BAR.SYNC、寄存器与 q，以及 barrier、short/long scoreboard、MIO 等可用 warp-state 指标。
源行/逐 PC 归属保存在 source_code_audits，不能把整个 kernel 的 shared traffic 都算成 ML。
shared swizzle 也改变 TensorMap 的 box 宽度和 TMA 指令分组；T_control 是匹配诊断，不是可以无条件线性扣除的已知底座。
因此本轮可以检验 H4 的方向、加载冲突是否有可测代价、其驻留响应和隔离程度；不能从这些共变数据直接求出唯一 MR 同步延迟系数。
若全 kernel barrier 百分比与叙事不一致，应保留该反例，而不能只看有利指标。
按 [NVIDIA NCU 文档](https://docs.nvidia.com/nsight-compute/ProfilingGuide/)，short scoreboard/MIO 涉及 shared、特殊函数或分支等多种操作；warp-state 百分比不能直接相加为阶段纳秒。

## 5. 原始证据、复核与停点

[全部计数摘要](COUNTERS.md)；完整 FULL 三点斜率与各 worker 原始时间见 analysis.json，全部原始事件见 timing/invocation_*/raw.json。
compile_gate.json/compiled_payload.zip 固定实际 CUBIN；artifact_gate.json 绑定真实寄存器、local bytes、q 与正确性。
profiles/*/attempt_*/export 保存 ncu-rep、source/raw CSV、worker UUID 与实际加载 SHA；offline_import_validation.json 保存独立本地重导入核对。
诊断只使用本阶段冻结数据，不把历史 26.6 µs 或人工总分引入模型。

M4a 首次 CPU preflight 在编译前发现上传快照遗漏 c16/kernels.py；失败 dispatch/retrieval 记录保留，CPU-only packaging revision 增补依赖，36 个程序与指标清单未改，未产生 GPU 样本。
本阶段通过 validator 后生成 freeze.json、commit/push。只继续用户已授权的 M4a/M4b，全部完成后停下；没有新模型拟合、C++ 修改、PR 或跨架构实验。
